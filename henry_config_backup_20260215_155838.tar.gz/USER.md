# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** Brian
- **What to call them:** Brian
- **Pronouns:** *(to be confirmed)*
- **Timezone:** Currently Taiwan (UTC+8) — splits time between Hawaii, Philippines, Taiwan (most time in Hawaii)
- **Email:** shukribr@gmail.com
- **Notes:** Reached out via Telegram (@RRT5N) 

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
